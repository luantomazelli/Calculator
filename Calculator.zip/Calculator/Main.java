

public class Main {
	public static void main(String[] arguments)
	{
		Calculator c = new Calculator ();
}
}